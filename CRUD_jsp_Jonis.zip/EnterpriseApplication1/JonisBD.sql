# MySQL-Front 3.2  (Build 14.8)

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES latin1 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='SYSTEM' */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE */;
/*!40101 SET SQL_MODE='STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES */;
/*!40103 SET SQL_NOTES='ON' */;


# Host: 127.0.0.1    Database: jonis
# ------------------------------------------------------
# Server version 5.0.45-community-nt

DROP DATABASE IF EXISTS `jonis`;
CREATE DATABASE `jonis` /*!40100 DEFAULT CHARACTER SET latin1 */;
USE `jonis`;

#
# Table structure for table cliente
#

CREATE TABLE `cliente` (
  `id` int(11) NOT NULL auto_increment,
  `nome` varchar(20) default NULL,
  `cpf` int(11) default NULL,
  `telefone` int(11) default NULL,
  `email` varchar(20) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=latin1 ROW_FORMAT=REDUNDANT;

#
# Dumping data for table cliente
#

INSERT INTO `cliente` VALUES (14,'w',1,2,'paula@palmira');
INSERT INTO `cliente` VALUES (15,'Vavassori',2334444,11233444,'testeste@testet');

#
# Table structure for table item
#

CREATE TABLE `item` (
  `id` int(11) NOT NULL auto_increment,
  `qtditem` int(11) NOT NULL default '0',
  `valor_item` double NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# Dumping data for table item
#


#
# Table structure for table pedido
#

CREATE TABLE `pedido` (
  `id` int(11) NOT NULL auto_increment,
  `valor` float NOT NULL default '0',
  `datapedido` datetime NOT NULL default '0000-00-00 00:00:00',
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# Dumping data for table pedido
#


#
# Table structure for table produto
#

CREATE TABLE `produto` (
  `id` int(11) NOT NULL auto_increment,
  `nomeprod` varchar(20) collate latin1_bin default NULL,
  `descricao` varchar(100) collate latin1_bin default NULL,
  `qtdprod` int(11) default NULL,
  `valor_prod` double NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

#
# Dumping data for table produto
#


#
#  Foreign keys for table item
#

ALTER TABLE `item`
  ADD FOREIGN KEY (`id`) REFERENCES `pedido` (`id`);


/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
