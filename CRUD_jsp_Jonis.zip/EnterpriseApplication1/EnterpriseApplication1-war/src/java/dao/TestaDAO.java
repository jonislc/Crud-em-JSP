/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import model.Cliente;

/**
 *
 * @author jonis.silva.neves
 */
public class TestaDAO {
    public static void main(String[]args){
        alterar();
    }
    
    public void inserir(){
        try{
            DAO dao = new DAO();
            dao.conecta();
            Cliente cli = new Cliente();
            cli.setNome("Teste");
            cli.setCpf(Integer.parseInt("12345"));
            cli.setTelefone(Integer.parseInt("12345"));
            cli.setEmail("teste@teste");       
            dao.deletarCliente(cli.getId());
            System.out.println("Cliente cadastrado com exito");
            dao.desconecta();
     }catch(Exception ex){
         System.out.println("Erro ao efetuar cadastro no banco");
         throw new RuntimeException();
     }
    }
    
    public static void deletar(){
        try{
        DAO dao = new DAO();
        dao.conecta();
        Cliente cli = new Cliente();
        cli.setId(6);
        dao.deletarCliente(cli.getId());
        System.out.println("Cliente deletado com exito");
        dao.desconecta();
     }catch(Exception ex){
         System.out.println("Erro ao efetuar exclusao no banco");
         throw new RuntimeException();
     }
    }
    
        public static void alterar(){
            try{
                DAO dao = new DAO();
                dao.conecta();
                Cliente cli = new Cliente();
                cli.setId(14);
                cli.setNome("paula");
                cli.setCpf(10101010);
                cli.setTelefone(122220);
                cli.setEmail("paula@paulis");
                dao.atualizarCliente(cli);
                System.out.println("Cliente alterado com exito");
                dao.desconecta();
            }catch(Exception ex){
                System.out.println("Erro ao efetuar alteracao no banco");
                throw new RuntimeException();
        }
    }
}
