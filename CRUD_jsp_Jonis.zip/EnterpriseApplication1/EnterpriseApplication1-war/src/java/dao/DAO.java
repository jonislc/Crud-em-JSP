package dao;

import com.mysql.jdbc.PreparedStatement;
import com.sun.jndi.ldap.Connection;
import model.Produto;
import dao.Conexao;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import model.Cliente;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author jonis.silva.neves
 */
public class DAO {

    private java.sql.Connection conexao;
    private PreparedStatement preparestatement;
    private Statement st;
    private ResultSet rs;
    private ArrayList<Cliente> lista = new ArrayList<>(); 
    
    public void conecta() {
        try {
            conexao = new Conexao().getConexaoMySQL();
        } catch (Exception ex) {
        }

    }
    public void desconecta() throws SQLException {
        conexao.close();
    }
    public void criarProduto() {

    }
    
    public ArrayList<Cliente> listarProdutos() {

        String sql = "SELECT * FROM cliente";
        try{
            st = conexao.createStatement();
            rs = st.executeQuery(sql);
            while(rs.next()){
                Cliente cliente = new Cliente();
                cliente.setId(rs.getInt("id"));
                cliente.setNome(rs.getString("nome"));
                cliente.setCpf(rs.getInt("cpf"));
                cliente.setTelefone(rs.getInt("telefone"));
                cliente.setEmail(rs.getString("email"));
                lista.add(cliente);
            }
            st.close();
        }catch(Exception erro){
        
        }
        return lista;
    }

    public void inserirCliente(Cliente cliente) {
        String sql = "INSERT INTO cliente (nome, cpf, telefone, email) VALUES(?,?,?,?)";
        try{
            preparestatement = (PreparedStatement) conexao.prepareStatement(sql);
            preparestatement.setString(1, cliente.getNome());
            preparestatement.setInt(2, cliente.getCpf());
            preparestatement.setInt(3, cliente.getTelefone());
            preparestatement.setString(4, cliente.getEmail());
            preparestatement.execute();     
            preparestatement.close();
        }catch(Exception e){
            
        }
        
    }
    
    public void inserirProduto() {

    }

    public void alterarProduto() {

    }

    public void deletarProduto() {

    }
    
    public void deletarCliente(int id) {
        String sql = "DELETE FROM cliente WHERE id = "+id;
        try{
            st = conexao.createStatement();
            st.execute(sql);
            st.close();
        }catch(Exception e){
            throw new RuntimeException();
        }

    }
    
    public void atualizarCliente(Cliente cliente) {
        String sql = "UPDATE cliente SET nome = ?, cpf = ?, telefone = ?,email = ? WHERE id = ?";
        try{
            preparestatement = (PreparedStatement) conexao.prepareStatement(sql);
            preparestatement.setString(1, cliente.getNome());
            preparestatement.setInt(2, cliente.getCpf());
            preparestatement.setInt(3, cliente.getTelefone());
            preparestatement.setString(4, cliente.getEmail());
            preparestatement.setInt(5, cliente.getId());
            preparestatement.execute();     
            preparestatement.close();
        }catch(Exception e){
            throw new RuntimeException();
        }

    }
}
